APP_Path = app:info('path')
UI_Path = sui:info('uipath')

function onload()
  UI_Inited = 0
  UI_Inited = 1
end

